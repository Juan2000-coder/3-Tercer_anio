import RPi.GPIO as GPIO
import time
GPIO.setmode(GPIO.BCM)
GPIO.setup(22, GPIO.OUT) ## GPIO 17 como salida
GPIO.setup(27, GPIO.OUT) ## GPIO 27 como salida
GPIO.setup(17, GPIO.OUT) ## GPIO 27 como salida
iteracion = 0
while 1: ## Segundos que durara la func
    print("a")
    GPIO.output(27, True)  ## Enciendo el 27
    GPIO.output(22, False) ## Apago el 22
    GPIO.output(17, False) ## Apago el 17
    time.sleep(0.1) ## Esperamos 1 segundo
    GPIO.output(27, False) ## Apago el 27
    GPIO.output(22, True)  ## Enciendo el 22
    GPIO.output(17, False) ## Apago el 17
    time.sleep(0.1)
    GPIO.output(27, False) ## Apago el 27
    GPIO.output(22, False) ## Apago el 22
    GPIO.output(17, True)  ## Enciendo el 17
    time.sleep(0.1)
GPIO.cleanup() ## Hago una limpieza de los GPIO

