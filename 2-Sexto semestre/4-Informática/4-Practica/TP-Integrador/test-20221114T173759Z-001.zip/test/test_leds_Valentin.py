import RPi.GPIO as GPIO
import time
GPIO.setmode(GPIO.BCM)
GPIO.setup(22, GPIO.OUT) ## GPIO 17 como salida
GPIO.setup(27, GPIO.OUT) ## GPIO 27 como salida
GPIO.setup(17, GPIO.OUT) ## GPIO 27 como salida
iteracion = True
print("Inicio del programa ")
while iteracion: ## Iteraciones que durara la func

    GPIO.output(27, True)  ## Enciendo el 27
    GPIO.output(22, False) ## Apago el 22
    GPIO.output(17, False) ## Apago el 17
    time.sleep(1) ## Esperamos 1 segundo
    GPIO.output(27, False) ## Apago el 27
    GPIO.output(22, True)  ## Enciendo el 22
    GPIO.output(17, False) ## Apago el 17
    time.sleep(1)
    GPIO.output(27, False) ## Apago el 27
    GPIO.output(22, False) ## Apago el 22
    GPIO.output(17, True)  ## Enciendo el 17
    time.sleep(1)
    GPIO.output(27, True) ## Enciendo el 27
    GPIO.output(22, True) ## Enciendo el 22
    GPIO.output(17, True) ## Enciendo el 17
    time.sleep(1)
    GPIO.output(27, False) ## Apago el 27
    GPIO.output(22, False) ## Apago el 22
    GPIO.output(17, False) ## Apago el 17
    time.sleep(1)
print("Fin del programa ")
GPIO.cleanup() ## Hago una limpieza de los GPIO
