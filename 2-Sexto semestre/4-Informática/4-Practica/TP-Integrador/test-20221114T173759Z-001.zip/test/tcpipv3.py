#imports
import RPi.GPIO as GPIO
import time
import os
import sys
from datetime import datetime
import socket
import numpy as np
import encodings
from threading import Thread

os.system('modprobe w1-gpio')     #cargamos los drivers del dispositivo
os.system('modprobe w1-therm')

#Carpeta del Sensor de Temperatura
Carpeta_Sensor = '/sys/bus/w1/devices/28-0316b5ed2dff'
#Conexion TCP/IP

HOST = '192.168.100.49'
PORT = 60000

#pinouts
p_pulsador=3
p_verde=22
p_rojo=27
p_amarillo=17

#Inicializacion
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(p_pulsador, GPIO.IN) ## pulsador como entrada
GPIO.setup(p_verde, GPIO.OUT) ## ledverde como salida
GPIO.setup(p_rojo, GPIO.OUT) ## ledrojo como salida
GPIO.setup(p_amarillo, GPIO.OUT) ## ledamarillo como salida

GPIO.output(p_verde, False) ## Apago el ledverde
GPIO.output(p_rojo, False) ## Apago el ledrojo
GPIO.output(p_amarillo, False) ## Apago el ledamarillo

#############################################################################################

#variables iniciales

t_ciclo=2 ##tiempo de ciclo
t_ant_ciclo=0
t_inicial_boton=0
t_aux_leds=0
ultimos = list()
percent_variacion = 0.05 ## 5%
n_lecturas=5 ##cantidad de lecturas (N)
flag_boton=False
flag_leds=False
CONEXION = False
conn = False
addr = False
led_ant="nan"

#___________________________________LECTURA DE TEMPERATURA__________________________________
def leer_temp():
    fSensor = open(Carpeta_Sensor + '/w1_slave','r')
    linSensor = fSensor.readlines()
    posTemp = linSensor[1].find('t=')
    strTemp = linSensor[1][posTemp+2:]
    temperatura = int(strTemp)/1000
    fSensor.close()
    ultimos.append(temperatura)
    if len(ultimos)>n_lecturas:     #Guarda la lectura en la lista de temperaturas: 
        ultimos.pop(0)              #si el numero de lecturas supera las necesarias elimina la mas vieja
        
#______________________________________MODIFICADOR LEDS_____________________________________
def led_state(val):
    GPIO.output(p_verde, val=="ver" or val=="all")
    GPIO.output(p_rojo, val=="roj" or val=="all")
    GPIO.output(p_amarillo, val=="ama" or val=="all")
    
#_______________________________________PROMEDIO DE TEMPERATURAS____________________________
def sacar_promedio():
    resultado = 0
    for temp in ultimos:
        resultado=resultado+temp
    resultado=resultado/len(ultimos)
    return resultado
    
#_______________________________MODIFICADOR DE ESTADO RESPECTO A LA TENDENCIA_______________
def cambiar_estado_leds(prom,temp_actual):
    desviacion= temp_actual-prom
    global led_ant
    if desviacion > prom*percent_variacion:
        led_ant="roj"
        led_state("roj")
        return 'alta'
    elif desviacion < (-1)*(prom*percent_variacion):
        led_ant="ver"
        led_state("ver")
        return 'baja'
    else:
        led_ant="ama"
        led_state("ama")
        return 'estable'
        
#________________________________________GUARDA DATOS EN EL ARCHIVO__________________________
def guardar_datos(temperatura,tend):
    fyh_actual = datetime.now()
    fyh_txt = fyh_actual.strftime('%d/%m/%Y %H:%M:%S')
    with open('Informe.txt','a') as datos:
        info=str(fyh_txt)+' '+str("{:.3f}".format(temperatura))+' tendencia:'+tend+'\n'
        datos.write(info)

####------------------------########################---------------------####################
def enviarInfo(message, sock):
    try:
        global CONEXION
        global conn
        # codifica el mensaje
        encodedMessage = message.encode('utf-8')
        # envia el mensaje
        sock.sendall(encodedMessage)
    except:
        CONEXION = False
        conn = False
        print("DESCONEXION")
####------------------------########################----------------------####################
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((HOST, PORT))
s.listen()        

def realizar_conexion():
    global conn
    global addr
    global CONEXION
    global conexiones
    while 1:
        if not CONEXION:
            conn, addr = s.accept()
            print(f"Conectado por {addr}")
            CONEXION = True
    
####------------------------########################----------------------####################

try:
    print("Esperando conexion")
    hilo1 = Thread(target = realizar_conexion)
    hilo1.start()

    datos=open('Informe.txt','w')
    datos.close()
    tend=''
    led_state("all")
    print("actual    |   promedio")
    print("______________________")
    h_flag=False
    
    while 1:
        t_act = time.time() #tiempo actual
        if (t_act-t_ant_ciclo)>t_ciclo and not flag_boton:
            t_ant_ciclo=t_act
            if(flag_leds):
                flag_leds=False
                led_state(led_ant)
            leer_temp()
            temp_actual=ultimos[len(ultimos)-1]
            data=str(temp_actual)
            
            if CONEXION:
                enviarInfo(data,conn)
            prom=sacar_promedio()
            
            print("{:.3f}".format(temp_actual),"   |  ","{:.3f}".format(prom))
            if len(ultimos)>=n_lecturas:
                tend=cambiar_estado_leds(prom,temp_actual)
                guardar_datos(temp_actual,tend)
        elif (t_act-t_ant_ciclo)>(t_ciclo-0.1) and len(ultimos)>=n_lecturas and not flag_leds and not flag_boton:
            #print(t_act)
            led_state("all")
            flag_leds=True
       
       ###################################Secuencia para pulsador###########################################
        if not GPIO.input(p_pulsador) and not flag_boton:
            led_state("nan")
            t_inicial_boton=t_act
            flag_boton = True
        elif flag_boton and GPIO.input(p_pulsador):
            flag_boton = False
            t_ciclo=t_act-t_inicial_boton
            if t_ciclo<1:
                enviarInfo('fin',conn)
                print("Ejecucion finalizada")
                led_state("nan")
                sys.exit()
            elif t_ciclo<2.5:
                t_ciclo=2.5
            elif t_ciclo>10:
                t_ciclo=10
            print("tiempo de ciclo: ",t_ciclo)
        elif flag_boton:
            if (t_act-t_aux_leds)>1.1:
                led_state("nan")
                t_aux_leds=t_act
            elif (t_act-t_aux_leds)>1:
                led_state("all")
                flag_leds=True
    
#############################################################################################
except KeyboardInterrupt:
        pass

finally:
    GPIO.cleanup()
