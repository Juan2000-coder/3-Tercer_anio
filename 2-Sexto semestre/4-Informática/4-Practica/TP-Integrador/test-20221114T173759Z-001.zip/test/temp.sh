modprobe w1-gpio
modprobe w1-therm
ls /sys/bus/w1/devices

