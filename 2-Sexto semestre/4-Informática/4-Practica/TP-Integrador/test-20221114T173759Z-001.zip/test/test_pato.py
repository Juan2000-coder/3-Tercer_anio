import RPi.GPIO as GPIO
import time
import os
import sys

"""
Detalles de configuracion y carga del modulo del sistema operativo


/boot/config.txt
dtoverlay=w1-gpio,gpiopin=4

sudo modprobe w1-gpio
sudo modprobe w1-therm
cat /sys/bus/w1/devices/28-0316b5ed2dff/w1_slave
"""

#podemos cargarlo directo en python...
os.system('modprobe w1-gpio')     #cargamos los drivers del dispositivo
os.system('modprobe w1-therm')

#leo el contenido del sensor en linSensor y proceso...
Carpeta_Sensor = '/sys/bus/w1/devices/28-0316b5ed2dff'
##fSensor.close()

#muestro ambas lineas
#print(linSensor[0])
#print(linSensor[1])

#se que está en la segunda, pero en que posición?
def leer_temp():
    fSensor = open(Carpeta_Sensor + '/w1_slave','r')
    linSensor = fSensor.readlines()
    posTemp = linSensor[1].find('t=')
    #guardo desde esa posición hasta el final...
    strTemp = linSensor[1][posTemp+2:]
    temperatura = int(strTemp)/1000
    fSensor.close()
    #muestro resultado
    print("temperatura:",temperatura)
    return temperatura



pulsador=3
verde=22
rojo=27
amarillo=17

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(pulsador, GPIO.IN) ## pulsador como entrada
GPIO.setup(verde, GPIO.OUT) ## led1 como salida
GPIO.setup(rojo, GPIO.OUT) ## led2 como salida
GPIO.setup(amarillo, GPIO.OUT) ## led3 como salida

GPIO.output(verde, False) ## Apago el led1
GPIO.output(rojo, False) ## Apago el led2
GPIO.output(amarillo, False) ## Apago el led3

try:
    print("Ejecucion iniciada...")
    
    #print("estado pulsador:",GPIO.input(pulsador))
    #print("presione el pulsador")
    a=1
    while a==0:
            if not GPIO.input(pulsador):
                print("   gracias!")
                print("   estado pulsador:",GPIO.input(pulsador))

                a=10            
    iteracion = 0
    
    print("Entrando en bucle de iteracion de leds")
    while 1: ## Segundos que durara la funcion
                    print("tiempo=",time.time())
                    temperatura=leer_temp()
                    GPIO.output(verde, temperatura<26) ## Enciendo el led1
                    GPIO.output(rojo, False) ## Apago el led2
                    GPIO.output(amarillo, False) ## Apago el led3

                    time.sleep(0.3) ## Esperamos 1 segundo
                    
                    GPIO.output(verde, False) ## Apago el led1
                    GPIO.output(rojo, False) ## Enciendo el led2
                    GPIO.output(amarillo, False) ## Apago el led3

                    time.sleep(0.3) ## Esperamos 1 segundo
                    
                    #GPIO.output(verde, False) ## Apago el led1
                    #GPIO.output(rojo, False) ## Apago el led2
                    #GPIO.output(amarillo, True) ## Prendo el led3

                    #time.sleep(0.4) ## Esperamos 1 segundo'''

    print("Ejecucion finalizada")
    sys.exit()

except KeyboardInterrupt:
        pass

finally:
    GPIO.cleanup()